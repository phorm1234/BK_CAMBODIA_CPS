<?php
if(!empty($_GET['reason_id'])){ $_POST['reason_id']=$_GET['reason_id'];}
if(!empty($_GET['reason_name'])){ $_POST['reason_name']=$_GET['reason_name'];}
if(!empty($_GET['time_name'])){ $_POST['time_name']=$_GET['time_name'];}
if(!empty($_GET['time_id'])){ $_POST['time_id']=$_GET['time_id'];}

if(!empty($_POST['enter'])){
	
	$today=date("Y-m-d");
	global $local;
	
	if($_POST['reason_id']=='1'){
		$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='1'";
		echo "$sql===\r\n";
		$rs=mysql_query($sql);
		if(@mysql_num_rows($rs)=='0'){
			finger_scan($_POST['cid'],$_POST['time_id'],$_POST['reason_id']);
		}else{
			$arr=mysql_fetch_array($rs);
			echo show_msg("�ѹ��� �سŧ���� ��ҷӧҹ����� ����� $arr[check_in]",3);
		}
	}elseif($_POST['reason_id']=='2'){
		$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='1'";
		$rs=mysql_query($sql);
		if(@mysql_num_rows($rs)=='0'){
			echo show_msg("�س��ͧŧ������ҷӧҹ ��͹ �֧��ŧ������ԡ�ҹ��",3);
		}else{
			$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='3'";
			$rs=mysql_query($sql);
			if(@mysql_num_rows($rs)=='0'){
				$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='2'";
				$rs=mysql_query($sql);
				if(@mysql_num_rows($rs)=='0'){
					$_POST['time_id']=get_first_time_id($_POST['cid'],$today);
					capture($_POST['cid'],$_POST['time_id'],$_POST['reason_id']);
				}else{
					$arr=mysql_fetch_array($rs);
					echo show_msg("�ѹ��� �سŧ������ԡ�ҹ����� ����� $arr[check_in]",3);
				}
			}else{
				$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='4'";
				$rs=mysql_query($sql);
				if(@mysql_num_rows($rs)=='0'){
					$arr=mysql_fetch_array($rs);
					echo show_msg("�س��ͧŧ���� ��Ѻ�ҡ�ѡ�ҹ���ǡ�͹ �֧��ŧ������ԡ�ҹ��",3);
				}else{
					$_POST['time_id']=get_first_time_id($_POST['cid'],$today);
					capture($_POST['cid'],$_POST['time_id'],$_POST['reason_id']);
				}
			}
		}
	}elseif($_POST['reason_id']=='3'){
		
		$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='1'";
		$rs=mysql_query($sql);
		if(@mysql_num_rows($rs)=='0'){
			echo show_msg("�س��ͧŧ������ҷӧҹ��͹ �֧��ŧ���� �ѡ�ҹ������",3);
		}else{
			$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='3'";
			$rs=mysql_query($sql);
			if(@mysql_num_rows($rs)=='0'){
				$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='2'";
				$rs=mysql_query($sql);
				if(@mysql_num_rows($rs)=='0'){
					$_POST['time_id']=get_first_time_id($_POST['cid'],$today);
					capture($_POST['cid'],$_POST['time_id'],$_POST['reason_id']);
				}else{
					echo show_msg("�سŧ������ԡ�ҹ����� �������öŧ���Ҿѡ�ҹ�����",3);
				}
			}else{
				$arr=mysql_fetch_array($rs);
				echo show_msg("�ѹ��� �سŧ���Ҿѡ�ҹ��������� ����� $arr[check_in]",3);
			}
		}
	}elseif($_POST['reason_id']=='4'){
		$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='3'";
		$rs=mysql_query($sql);
		if(@mysql_num_rows($rs)=='0'){
			echo show_msg("�س��ͧŧ���Ҿѡ�ҹ���ǡ�͹  �֧��ŧ���ҡ�Ѻ�ҡ�ѡ�ҹ������",3);
		}else{
			$sql="select * from check_in_out where cid = '$_POST[cid]' and check_date='$today' and check_in_reason='4'";
			$rs=mysql_query($sql);
			if(@mysql_num_rows($rs)=='0'){
				$_POST['time_id']=get_first_time_id($_POST['cid'],$today);
				capture($_POST['cid'],$_POST['time_id'],$_POST['reason_id']);
			}else{
				$arr=mysql_fetch_array($rs);
				echo show_msg("�ѹ��� �سŧ���ҡ�Ѻ�ҡ�ѡ�ҹ��������� ����� $arr[check_in]",3);
			}
		}
	}

}else{

	//print_r($_SERVER);
	
	//echo $_SERVER['REMOTE_ADDR']."<br>";
	
	if($_SERVER['REMOTE_ADDR'] == "localhost" or $_SERVER['REMOTE_ADDR'] == "127.0.0.1"){
		$finger_ip="localhost";	
	}else{
		$finger_ip=$_SERVER['SERVER_ADDR'];
	}
	
	echo"
	<table align='center' border='0' cellpadding='0' cellspacing='0' width='100%' height='100%'>
	<tr bgcolor='#ffffff'>
		<td align='center' width='250'><a href='index.php'><img src='img/logo.jpg' border='0'></a></td>
		<td height='80' align='right' style='padding-right:30;'>&nbsp;</td>
	</tr>
	<tr>
		<td colspan='2' bgcolor='#d0d0d0' height='1'><img src='img/spacer.gif' height='1'></td>
	</tr>
	<tr>
		<td bgcolor='#ffffff' valign='top' align='center' colspan='2'>
		<br><br><br>
		
		<table cellspacing='0' cellpadding='0' border='0'>
		<form method='post' id='flogin' name='flogin'>
		<tr>
			<td align='center' colspan='2'><font size='+3'>$_POST[reason_name]<br>�� $_POST[time_name]</font><hr></td>
		</tr>
		<tr>
			<td align='center'><iframe src='http://127.0.0.1:8081' align='middle' marginwidth='0' marginheight='0' width='320' height='240' frameborder='0'></iframe></td>
			<td align='center'><iframe id='finger_frame' src='' align='middle' marginwidth='0' marginheight='0' width='600' height='350' frameborder='0'></iframe></td>
		</tr>
		<tr>
			<td align='center'  colspan='2'><hr></td>
		</tr>
		<input type='hidden' readonly='readonly' name='cid' id='cid' class='FS' maxlength='6' autocomplete='off'>
		<input type='hidden' id='reason_id' name='reason_id' value='$_POST[reason_id]'>
		<input type='hidden' id='time_id' name='time_id' value='$_POST[time_id]'>
		<input type='hidden' id='enter' name='enter' value='checking' >
		<input type='hidden' id='check_by' name='check_by'>
		</form>
		</table>
		
		</td>
	</tr>
	</table>
	";
	
	
	if($_POST['submit']=='capture')
	{
		//echo"<script>flogin.cid.focus();</script>";
	?>
		
	<script>

	document.observe("dom:loaded", function() {
		$('check_by').value = 'finger';
		setTimeout(function(){ $('finger_frame').src='http://<?php echo $finger_ip; ?>/finger_shop/index.php/compare'; },500);
		setTimeout(function(){ $('finger_frame').src='http://<?php echo $finger_ip; ?>/finger_shop/index.php/compare'; },500);
		setTimeout(check_finger_print,1500);
	});

	
	function check_finger_print(){
		new Ajax.Request("http://<?php echo $finger_ip;?>/finger_shop/finger/user_id.txt",{
			method: 'get',
			onSuccess: function(res){
				if(res.responseText != ""){
					var finger_user_id = res.responseText;
					if(res.responseText != "not_found"){

						if(res.responseText != "000000" && res.responseText != ""){
							//alert('='+res.responseText+'=');
							var user_id=finger_user_id.split("_");
							$('cid').value=user_id[0];
					
							//$('flogin').submit();
								
							new Ajax.Request("finger_checkin.php",{
								method: 'POST',
								asynchronous: true,
								parameters: { 
									'submit' : 'capture',
									'enter': 'checking',
									'reason_id' : $('reason_id').value,
									'time_id' : $('time_id').value,
									'cid' : user_id[0],
									'check_by' : $('check_by').value,
									'unlock_code' : user_id[1]
								},
								onComplete: function(res){ 
									var data = res.responseText
									var arr = data.split("|");
									if(arr[0]=="N"){
										//alert(arr[1]);
										setTimeout(function(){ $('finger_frame').src='http://<?php echo $finger_ip; ?>/finger_shop/index.php/compare'; },500);
									}else{
										//alert("ok - remark redirect");
										window.location='index.php';
									} 
								}
							});
						}else{
							setTimeout(check_finger_print,1000);
						}
						
					}else{
						$('check_by').value = 'idcard';
						setTimeout(function(){ $('finger_frame').src='http://<?php echo $finger_ip; ?>/finger_shop/index.php/idcard'; },500);
						setTimeout(function(){ $('finger_frame').src='http://<?php echo $finger_ip; ?>/finger_shop/index.php/idcard'; },500);
						setTimeout(check_finger_print,1500);
					}
				}else{
					setTimeout(check_finger_print,1000);
				}
			}
		});
	}
	
	</script>
		
	<?php 
	}
}
?>
