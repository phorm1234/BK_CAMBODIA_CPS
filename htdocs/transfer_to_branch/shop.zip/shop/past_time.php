<?php
include "inc/session.php";
include "inc/config.php";
include "inc/function.php";
include "inc/header.php";

echo"
<table width='100%' height='100%' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor='#ffffff'>
<tr bgcolor='#ffffff'>
	<td align='center' width='250'><a href='index.php'><img src='img/logo.jpg' border='0'></a></td>
	<td height='80' align='right' style='padding-right:30;'>&nbsp;</td>
</tr>
<tr>
	<td colspan='2' bgcolor='#d0d0d0' height='1'><img src='../../img/spacer.gif' height='1'></td>
</tr>
<tr>
	<td bgcolor='#ffffff' align='center' height='100%' valign='top' colspan='2'>
";

if(!empty($_GET['submit'])){ $_POST['submit']=$_GET['submit'];}
if(!empty($_POST['submit'])){
	include "src/$_POST[submit].php";
}else{
	include "src/select_past_time.php";
}

echo"
	</td>
</tr>
</table>
";

?>
