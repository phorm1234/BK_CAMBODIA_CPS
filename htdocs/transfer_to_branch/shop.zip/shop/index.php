<?php
session_start();
include "inc/config.php";
include "inc/auth.php";
include "inc/function.php";
include "inc/header.php";

system("rm -f snapshot.*");

/* ================== NEW ================== */
@system('echo "" > /var/www/pos/htdocs/finger_shop/finger/user_id.txt ');
$sqlc1="SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'ssup' AND TABLE_NAME = 'check_in_out' AND COLUMN_NAME = 'cid'";
$rsc1=mysql_query($sqlc1,$local);
if(@mysql_num_rows($rsc1) > 0){
	$arrc1=mysql_fetch_assoc($rsc1);
	if($arrc1['CHARACTER_MAXIMUM_LENGTH'] < 20){
		$alt="ALTER TABLE `check_in_out` CHANGE `cid` `cid` VARCHAR( 20 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL";
		mysql_query($alt,$local);
	}
}

$sqlc2="SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'ssup' AND TABLE_NAME = 'check_in_out' AND COLUMN_NAME = 'cid2'";
$rsc2=mysql_query($sqlc2,$local);
if(@mysql_num_rows($rsc2) > 0){
	$arrc2=mysql_fetch_assoc($rsc2);
	if($arrc2['CHARACTER_MAXIMUM_LENGTH'] < 20){
		$alt2="ALTER TABLE `check_in_out` CHANGE `cid2` `cid2` VARCHAR( 20 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL";
		mysql_query($alt2,$local);
	}
}else{
	$alt2="ALTER TABLE `check_in_out` ADD `cid2` VARCHAR( 30 ) NOT NULL AFTER `cid` ";
	mysql_query($alt2,$local);
}

$ins_reason="INSERT IGNORE INTO reason  (`reason_id`, `reason_name`, `reason_flag`, `reason_type`) VALUES ('13','��ҧҹ�֡�Ѵ','1',''),('14','��ԡ�ҹ�֡�Ѵ','1','')";
mysql_query($ins_reason,$local);



/* ================== NEW ================== */


if(is_dir("/srv/www/htdocs/shop/")){
	@chdir("/srv/www/htdocs/shop");
	$tran_command="php -q -f tran.php >>/dev/null 2>>/dev/null &";
	exec($tran_command);
}else{
	@chdir("/var/www/shop");
	$tran_command="php -q -f tran.php >>/dev/null 2>>/dev/null &";
 	exec($tran_command);
}

//print_r($_SESSION);
$sql="select * from shop where brand='$_SESSION[brand]' and shop_number='$_SESSION[shop_number]' order by shop_id desc limit 1";
$rs=mysql_db_query(DB,$sql,$local);
$arr=mysql_fetch_array($rs,MYSQL_ASSOC);

$ex=explode(".",$arr['shop_ip']);
$rounter_ip="$ex[0].$ex[1].$ex[2].254";
$computer_ip="$arr[shop_ip]";
$cam1_ip="$arr[cam_ip_1]";
$cam2_ip="$arr[cam_ip_2]";
$cam3_ip="$ex[0].$ex[1].$ex[2].".($ex[3]+3);
$edc_ip="$ex[0].$ex[1].$ex[2].".($ex[3]+5);
$office_ip="192.168.252.240";
$bank1_ip="10.9.200.46";
$bank2_ip="10.9.200.54";
$mobile_ip="$ex[0].$ex[1].$ex[2].61";
$wifi_ip="$ex[0].$ex[1].$ex[2].254";
$jinet_ip="10.100.53.2";

if(!empty($_GET['submit'])){ $_POST['submit']=$_GET['submit'];}

if(!empty($_POST['submit'])){
	include "src/$_POST[submit].php";
}else{
	
	if(date("H") < 7){
		echo"
			<table cellpadding='0' cellspacing='0' border='0' height='100%' width='100%'>
			<tr>
				<td><table><tr><td></td></tr></table></td>
			</tr>
			<tr>
				<td align='center' style='font-size: 150%; font-weight: bold;'>
				<img border='0' src='img/logo.jpg'><br>
				�������öŧ���ҵ͹ ".date("Y-m-d H:i:s")." �� <br>
				��سҵ�Ǩ�ͺ����<br>
				</td>
			</tr>
			<tr bgcolor='#ffffff'>
				<td colspan='2' height='1' background='img/lines.gif'><img src='img/spacer.gif' height='1'></td>
			</tr>
			<tr>
				<td><table><tr><td></td></tr></table></td>
			</tr>
			</table>
		";
		exit();
	}
	
	echo"
	<table width='100%' height='100%' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor='#ffffff'>
	<tr bgcolor='#ffffff'>
		<td align='center'  width='250'><a href='index.php'><img src='img/logo.jpg' border='0'></a></td>
		<td colspan='2' height='80' align='right' style='padding-right:30;'>
		
			
			<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td width='60%'>
				
				<table cellpadding='0' cellspacing='0' border='0'>
				<tr align='center'>
					<td width='65' height='50'><div id='office_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='rounter_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='jinet_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='com_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='cam1_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='cam2_status' style='width:47; height:48;'></div></td>
					<td width='65'><div id='cam3_status' style='width:47; height:48;'></div></td>
					<td width='65'>
					<table cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td><div id='mobile_status' style='width:47; height:25;'></div></td>
					</tr>
					<tr>
						<td><div id='wifi_status' style='width:47; height:25;'></div></td>
					</tr>
					</table>
					</td>
					<td width='65'><div id='edc_status' style='width:47; height:48;'></div></td>
					<td width='65'>
					<table cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td><div id='bank1_status' style='width:47; height:25;'></div></td>
					</tr>
					<tr>
						<td><div id='bank2_status' style='width:47; height:25;'></div></td>
					</tr>
					</table>
					</td>
				</tr>
				<tr align='center'>
					<td width='65'><b>Office</b></td>
					<td width='65'><b>Rounter</b></td>
					<td width='65'><b>Ji-net</b></td>
					<td width='65'><b>Computer</b></td>
					<td width='65'><b>Cam1</b></td>
					<td width='65'><b>Cam2</b></td>
					<td width='65'><b>Cam3</b></td>
					<td width='65'><b>Wifi</b></td>
					<td width='65'><b>EDC</b></td>
					<td width='65'><b>BANK</b></td>
				</tr>
				</table>
				
				<input type='hidden' id='office_status_val' value='$office_ip' name='office'>
				<input type='hidden' id='rounter_status_val' value='$rounter_ip' name='rounter'>
				<input type='hidden' id='jinet_status_val' value='$jinet_ip' name='jinet'>
				<input type='hidden' id='com_status_val' value='$computer_ip' name='com'>
				<input type='hidden' id='cam1_status_val' value='$cam1_ip' name='cam1'>
				<input type='hidden' id='cam2_status_val' value='$cam2_ip' name='cam2'>
				<input type='hidden' id='cam3_status_val' value='$cam3_ip' name='cam3'>
				<input type='hidden' id='edc_status_val' value='$edc_ip' name='edc'>
				<input type='hidden' id='bank1_status_val' value='$bank1_ip' name='bank1'>
				<input type='hidden' id='bank2_status_val' value='$bank2_ip' name='bank2'>
				<input type='hidden' id='mobile_status_val' value='$mobile_ip' name='mobile'>
				<input type='hidden' id='wifi_status_val' value='$wifi_ip' name='wifi'>
				
				</td>
				<td width='40%' align='center'>
				
				<table width='100%' height='100%' cellpadding='0' cellspacing='0' border='0'>
				<tr>
					<td width='100%' height='100%' align='center'>
					
					&nbsp;<span id='brand_shop_number'>$_SESSION[brand]-$_SESSION[shop_number]</span>
					
					</td>
				</tr>
				<tr>
					<td><img src='img/spacer.gif' height='3'></td>
				</tr>
				<tr>
					<td  align='center'>&nbsp;<span id='shop_name'>$_SESSION[shop_name]</span></td>
				</tr>
				</table>
				
				</td>
			</tr>
			</table>
			
				
		</td>
	</tr>
	
	<tr>
		<td colspan='3' bgcolor='#d0d0d0'><img src='img/spacer.gif' height='1'></td>
	</tr>
	
	<tr>
		<td bgcolor='#ffffff' align='center' height='100%' valign='top'>
		<table width='100%' bgcolor='#cccccc' cellpadding='0' cellspacing='0' border='0'>
		"; 
		
		$i=1;
		mysql_select_db(DB,$local);
		$sql_time="select * from reason where reason_flag='1' ";
		$rs_time=mysql_query($sql_time);
		while($arr_time=mysql_fetch_array($rs_time))
		{
			if($arr_time[reason_id]=='2' || $arr_time[reason_id]=='14'){
				$alert="onclick=\"javascript:if(confirm('�س��ͧ���ŧ���� ��ԡ�ҹ �����?')){return true;}else{return false;};\"";
			}else{
				$alert="";
			}
			echo"
			<tr bgcolor='#ffffff'>
				<td><table><tr><td></td></tr></table></td>
			</tr>
			<tr bgcolor='#ffffff'>
			<form method='post' action='index.php'>
				<td valign='middle' align='center' height='35'>
					<input type='submit' value='$arr_time[reason_id] $arr_time[reason_name]' name='reason_name' class='button_c1' $alert>
					<input type='hidden' value='$arr_time[reason_id]' name='reason_id'>
					<input type='hidden' value='$arr_time[reason_name]' name='reason_name'>
					<input type='hidden' value='check_in_out' name='submit'>
				</td>
			</form>
			</tr>
			";
			
			if($i==2 or $i==4){
				echo"
				<tr bgcolor='#ffffff'>
					<td><table><tr><td></td></tr></table></td>
				</tr>
				<tr bgcolor='#ffffff'>
					<td>
					<table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>
					<tr>
						<td><img src='img/fline_left.jpg'></td>
						<td background='img/fline_center.jpg' width='100%'></td>
						<td><img src='img/fline_right.jpg'></td>
					</tr>
					</table>
					</td>
				</tr>
				";
			}
			$i++;
		}
		
		echo"
		<tr bgcolor='#ffffff'>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr bgcolor='#ffffff'>
		<form method='post' action='report.php'>
			<td valign='middle' align='center' height='35'>
				<input type='submit' value='��§ҹ' name='report' class='button_c1'>
			</td>
		</form>
		</tr>
		<tr bgcolor='#ffffff'>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr bgcolor='#ffffff'>
		<form method='post' action='past_time.php'>
			<td valign='middle' align='center' height='35'>
				<input type='submit' value='�к��˵ؼ� �����ŧ����' name='past_time' class='button_c1'>
			</td>
		</form>
		</tr>
		
                <tr bgcolor='#ffffff'>
                        <td><table><tr><td></td></tr></table></td>
                </tr>

		<tr bgcolor='#ffffff'>
			<td>
			<table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>
			<tr>
				<td><img src='img/fline_left.jpg'></td>
				<td background='img/fline_center.jpg' width='100%'></td>
				<td><img src='img/fline_right.jpg'></td>
			</tr>
			</table>
			</td>
		</tr>
		<tr bgcolor='#ffffff'>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr bgcolor='#ffffff'>
		<form method='post' action='emp_discount.php'>
			<td valign='middle' align='center' height='35'>
				<input type='submit' value='���Է��쾹ѡ�ҹ' name='emp_submit' class='button_c1'>
			</td>
		</form>
		</tr>

		<tr bgcolor='#ffffff'>
                        <td><table><tr><td></td></tr></table></td>
                </tr>
                <tr bgcolor='#ffffff'>
                        <td valign='middle' align='center' height='35'>
                                <input type='button' onclick=\"javascript:window.close();\" value='EXIT' name='exit' class='button_c1'>
                        </td>
                </tr>
				<tr bgcolor='#ffffff'>
                        <td><table><tr><td></td></tr></table></td>
                </tr>
		<tr bgcolor='#ffffff'>
		<form method='get' action='/fingerprint'>
			<td valign='middle' align='center' height='35'>
				<input type='submit' value='����¹������'  class='button_c1'>
			</td>
		</form>
		</tr>
	
		</table>
		</td>
		<td bgcolor='#d0d0d0'><img src='img/spacer.gif' width='1'></td>
		<td width='100%' valign='top' style='padding-left:10;' bgcolor='#ffffff'>
		<table cellpadding='0' cellspacing='0' border='0' width='100%'>
		";
		$today=date("Y-m-d");
		$sql="select * from check_in_out where shop_id='$_SESSION[shop_number]' and check_in_reason='1' and check_date = '$today' group by cid order by check_id desc";
		$rs=mysql_query($sql);
		while($arr=mysql_fetch_array($rs))
		{
			echo"
			<tr>
				<td><table><tr><td></td></tr></table></td>
			</tr>
			<tr>
				<td>".select_reason_all_show($today,$arr['shop_id'],$arr['cid'])."</td>
			</tr>
			<tr bgcolor='#ffffff'>
				<td colspan='2' height='1' background='img/lines.gif'><img src='img/spacer.gif' height='1'></td>
			</tr>
			<tr>
				<td><table><tr><td></td></tr></table></td>
			</tr>
			";
		}
		echo"
		</table>
		</td>
	</tr>
	<tr>
	
	</tr>
	</table>
	";
?>
<script>
document.observe("dom:loaded", function() {
	get_status("office_status");
	get_status("rounter_status");
	get_status("jinet_status");
	get_status("com_status");
	get_status("cam1_status");
	get_status("cam2_status");
	get_status("cam3_status");
	get_status("edc_status");
	get_status("mobile_status");
	get_status("wifi_status");
	get_status("bank1_status");
	get_status("bank2_status");
});

function get_status(objID){
	new Ajax.Request("status_ajax.php",{
		method: 'POST',
		asynchronous: true,
		parameters: {
			ip: $(objID+'_val').value,
			icon: $(objID+'_val').name
		},
		onLoading: function(){
			$(objID).innerHTML="<img src='img/icon_load.gif' border='0'>";
		},
		onSuccess: function(res){
			$(objID).innerHTML=res.responseText;
		}
	});
}
</script>
<?php 
}
?>

