<?php
	header("Expires: Sat, 1 Jan 2005 00:00:00 GMT");
	header("Last-Modified: ".gmdate( "D, d M Y H:i:s")."GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	header("content-type: application/x-javascript; charset=tis-620");
	
	$local2=mysql_connect("192.168.252.246","root","SSUP2007");
	//$local2=mysql_connect("192.168.2.10","root","SSUP2007");
	mysql_query("SET character_set_results=tis620");
	mysql_query("SET character_set_client = tis620");
	mysql_query("SET character_set_connection = tis620");
	
	$sql="select * from emp where user_id ='$_POST[user_id]'";
	$rs=mysql_db_query("intranet",$sql,$local2);
	if(@mysql_num_rows($rs) > 0){
		$arr=mysql_fetch_array($rs);
		
		if($_POST[check_by]=="finger"){
			echo"emp_level6('$_POST[user_id]','$_POST[brand]','$_POST[shop]','6')";
		}else{
			if($arr[emp_level] < 6){
				//If emp level less than 6 have to take a photo
				//echo"window.location='emp_camera.php?user_id=$_POST[user_id]&brand=$_POST[brand]&shop=$_POST[shop]&level=$arr[emp_level]';";
				echo"emp_level12345('$_POST[user_id]','$_POST[brand]','$_POST[shop]','$arr[emp_level]');";
			}else{
				echo"emp_level6('$_POST[user_id]','$_POST[brand]','$_POST[shop]','$arr[emp_level]');";
			}
		}
		
		
	}else{
		echo "alert('��辺��ѡ�ҹ���� $_POST[user_id]'); window.location='emp_discount.php';";
	}
	mysql_close($local2);
?>
