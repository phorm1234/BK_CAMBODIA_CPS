<?php
	include "inc/session.php";
	include "inc/config.php";
	include "inc/function.php";
	include "inc/header.php";
	
	echo"
<table align='center' border='0' cellpadding='0' cellspacing='0' width='100%' height='100%'>
<tr bgcolor='#ffffff'>
	<td align='center' width='250'>&nbsp;</td>
	<td height='80' align='right' style='padding-right:30;'>&nbsp;</td>
</tr>
<tr>
	<td colspan='2' bgcolor='#d0d0d0' height='1'><img src='../../img/spacer.gif' height='1'></td>
</tr>
<tr>
	<td bgcolor='#ffffff' valign='middle' align='center' colspan='2'>
	<table>
	<tr>
		<td align='center'><font size='+3'>�᡹���ʾ�ѡ�ҹ����ͧ������Է���</font></td>		
	</tr>
	<tr>
		<td align='center'><input type='text' name='member' id='member' class='FS' maxlength='6' autocomplete='off'></td>
	</tr>
	<tr>
		<td align='center' height='15'><div id='emp_loading'></div></td>		
	</tr>
	</table>
		
	</td>
</tr>
</table>
	";
?>


	<script type="text/javascript">
		$('member').focus(); 
		var clear_member='';
		
		function copy(inElement) {
			if (inElement.createTextRange) {
				var range = inElement.createTextRange();
				if (range && BodyLoaded==1)
				range.execCommand('Copy');
			}else{
				var flashcopier = 'flashcopier';
				if(!document.getElementById(flashcopier)) {
					var divholder = document.createElement('div');
					divholder.id = flashcopier;
					document.body.appendChild(divholder);
				}
				document.getElementById(flashcopier).innerHTML = '';
				var divinfo = '<embed src="_clipboard.swf" FlashVars="clipboard='+escape(inElement)+'" width="0" height="0" type="application/x-shockwave-flash" allowScriptAccess="always"></embed>';
				document.getElementById(flashcopier).innerHTML = divinfo;
			}
		}
		
		document.body.observe('contextmenu', Event.stop);
		
		$('member').observe('keypress', function(event){
			var k = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
			if($F('member').length==6 && k==13){
				//alert($F('member'));
				new Ajax.Request("emp_level_ajax.php",{
					method: 'POST',
					asynchronous: true,
					parameters: { 
						user_id: $F('member'),
						brand: '<?php echo"$_SESSION[brand]";?>',
						shop: '<?php echo"$_SESSION[shop_number]";?>'
					},
					onLoading: function(){ $('emp_loading').innerHTML="<img src='img/emp_loading.gif' border='0'>"; },
					onSuccess: function(){ 
						$('emp_loading').innerHTML="";
						$('member').value='';
						$('member').focus();
						eval(res.responseText); 
					}
				});
			}else{
				clear_member = setTimeout ("clear_value()",800);
				//if((k!=8) && (k<48) || (k>57) && (k<65 || k>90) ){
				//	event.stop();
				//}else{
				//	clear_member = setTimeout ("clear_value()",350);
				//}
			}
		});	

		function emp_level12345(user_id,brand,shop,level){
			var url='http://localhost/shop/emp_camera.php?user_id='+user_id+'&brand='+brand+'&shop='+shop+'&level='+level;
			window.location=url;
			 
		}
		
		function emp_level6(user_id,brand,shop,level){
			new Ajax.Request("emp_capture_ajax.php",{
				method: 'POST',
				asynchronous: true,
				parameters: { 
					user_id: user_id,
					brand: brand,
					shop: shop,
					level: level
				},
				onLoading: function(){ $('emp_loading').innerHTML="<img src='img/emp_loading.gif' border='0'>"; },
				onSuccess: function(){ 
					$('emp_loading').innerHTML="";
					$('member').value='';
					$('member').focus();
					eval(res.responseText); 
				}
			});
		}
	
		function clear_value(){
			$('member').value='';
			$('member').focus();
			clearTimeout(clear_member);
		}
	
		$('member').observe('keydown', function(event){
			if(event.ctrlKey==1){
				copy(' ');
			}else if(event.shiftKey){
				copy(' ');
			}
		});
			
		$('member').observe('focus', function(event){
			copy(' ');
		});
	</script>
