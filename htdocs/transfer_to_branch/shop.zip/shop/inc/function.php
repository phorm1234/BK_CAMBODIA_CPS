<?php

function get_check_reason($cid,$chk_date,$shop_id=""){
	global $local;
	if($shop_id==""){
		$sql="select * from check_reason where cid ='$cid' and check_date='$chk_date' group by shop_id";
	}else{
		$sql="select * from check_reason where cid ='$cid' and check_date='$chk_date' and shop_id ='$shop_id' group by shop_id";
	}
	$rs=mysql_query($sql);
	if($num=@mysql_num_rows($rs) > 0){
		$arr=mysql_fetch_array($rs);
		$reason_name=get_reason_name($arr['reason_id']);
		if( ($arr['check_in'] != "00:00:00") and  ($arr['check_out'] != "00:00:00")){
			$text="$reason_name $arr[check_in]-$arr[check_out]";
		}else{
			$text="$reason_name";
		}
		return "$text";
	}else{
		return "&nbsp;";
	}
}

function fping_num($ip){
	$aa="/usr/bin/fping $ip";
	exec($aa,$arr,$err);
	$ex=explode(" ",$arr[0]);
	if($ex[2]=="alive"){
		return 1;
	}else{
		return 0;
	}
}

function get_reason_name($reason_id){
	
	$sql="select * from reason where reason_id='$reason_id'";
	$rs=mysql_query($sql);
	$arr=mysql_fetch_array($rs);
	return $arr[reason_name]; 
}

function show_msg($msg,$time){
	$text="
	<table height='100%' width='100%' border='0' align='center' cellpadding='0' cellspacing='0' >
	<tr>
		<td align='center' valign='middle' >
		
		<table border='0' align='center' cellpadding='5' cellspacing='1' bgcolor='#cccccc'>
		<tr>
			<td align='center' valign='middle' bgcolor='#ffffff' class='font_150' height='100'>&nbsp; $msg &nbsp;</td>
		</tr>
		</table>
		
		</td>
	</tr>
	</table>
	<meta http-equiv='REFRESH' content='$time; url=index.php'>
	";
	return($text);
}

function cal_late($tin,$cin){
	if($tin=="00:00:00"){
		return "";
	}else{
		$cin=substr($cin,0,6)."00";
		$time_in=strtotime($tin);
		$check_in=strtotime($cin);
		$show_time=substr($cin,0,5);
		if( $check_in > $time_in ){
			$late=time_diff($check_in,$time_in);
		}else{
			return "";
		}
	}
	return $late;
}

function time_diff($date1,$date2){
	if( $date2 > $date1 ){ return ""; }
 	$diff = $date1-$date2;
	$seconds = 0;
	$hours   = 0;
	$minutes = 0;
	if($diff % 86400 <= 0)  //there are 86,400 seconds in a day
	{$days = $diff / 86400;}

	if($diff % 86400 > 0){
		$rest = ($diff % 86400);
	    $days = ($diff - $rest) / 86400;
		if( $rest % 3600 > 0 ){
			$rest1 = ($rest % 3600);
	        $hours = ($rest - $rest1) / 3600;
	        if( $rest1 % 60 > 0 ){
				$rest2 = ($rest1 % 60);
	            $minutes = ($rest1 - $rest2) / 60;
	            $seconds = $rest2;
	         }else{
				$minutes = $rest1 / 60;
			}
		}else{
			$hours = $rest / 3600;
		}
	}
	
	//$return="$days - $hours - $minutes - $seconds";
	$return="";
	if($days != '0'){ $return.="$days �ѹ "; }
	if($hours != '0'){ $return.="$hours ��. "; }
	if($minutes != '0'){ $return.="$minutes �."; }
	return $return;
}

function time_hr($diff){
	if($diff % 86400 > 0){
		$rest = ($diff % 86400);
	    $days = ($diff - $rest) / 86400;
		if( $rest % 3600 > 0 ){
			$rest1 = ($rest % 3600);
	        $hours = ($rest - $rest1) / 3600;
	        if( $rest1 % 60 > 0 ){
				$rest2 = ($rest1 % 60);
	            $minutes = ($rest1 - $rest2) / 60;
	            $seconds = $rest2;
	         }else{
				$minutes = $rest1 / 60;
			}
		}else{
			$hours = $rest / 3600;
		}
	}
	$return="";
	if($hours != '0'){ $return.="$hours ��."; }
	if($minutes != '0'){ $return.="$minutes �ҷ�"; }
	return $return;
}

function date_diff2($date1, $date2){
	$s = strtotime($date2)-strtotime($date1);
	$m = intval($s/86400); 
	return $m;
}

function check_late($tin,$cin){
	if($tin=="00:00:00"){
		$show_time=substr($cin,0,5);
		$re_time="<font color='#339900'>$show_time</font>";
		$re_status="<font color='#339900'>��ҧҹ</font>";
		$re_color="#339900";
	}elseif($tin=="00:##:00"){
		$show_time=substr($cin,0,5);
		$re_time="<font color='#f26522'>$show_time</font>";
		$re_status="";
		$re_color="#f26522";
	}else{
		$cin=substr($cin,0,5);
		$time_in=strtotime($tin);
		$check_in=strtotime($cin);
		$show_time=substr($cin,0,5);
		if( $check_in > $time_in ){
			$re_time="<font color='#ff0000'>$cin</font>";
			$re_status="<font color='#ff0000'>���</font>";
			$re_color="#ff0000";
		}else{
			$re_time="<font color='#339900'>$cin</font>";
			$re_status="<font color='#339900'>������</font>";
			$re_color="#339900";
		}
	}
	return array("t"=>$show_time,"s"=>$re_status,"k"=>$re_color,"r"=>$re_time);
}

function get_time_in($time_id){
	$sql="select * from time_in_out where time_id = '$time_id'";
	$rs=mysql_query($sql);
	$arr=mysql_fetch_array($rs,MYSQL_ASSOC);
	return($arr);
}

function select_reason_all_show($today,$shop_id,$cid){
	global $local;
	$sql="select * from check_in_out where cid='$cid' and check_in_reason in ('1','3','4','2') and shop_id='$shop_id' and check_date = '$today'  group by check_in_reason order by check_in_seq";
	$rs=mysql_query($sql);
	$i=1;
	$text1="";
	while($arr=mysql_fetch_array($rs,MYSQL_ASSOC))	{
		switch($arr['check_in_reason']){
			case 1 : 
				$sss="select * from check_in_out where cid ='$arr[cid]' and shop_id='$arr[shop_id]' and check_date='$arr[check_date]' and check_in_reason='1' order by check_id desc limit 1 ";
				$rss=mysql_query($sss);
				$arrs=mysql_fetch_array($rss,MYSQL_ASSOC);
				$arr_time_in=get_time_in($arrs['time_id']);
				$check_late=check_late($arr_time_in['time_in'],$arrs['check_in']);
			break;
			case 2 : 
				$sss="select * from check_in_out where cid ='$arr[cid]' and shop_id='$arr[shop_id]' and check_date='$arr[check_date]' and check_in_reason='2' order by check_id limit 1 ";
				$rss=mysql_query($sss);
				$arrs=mysql_fetch_array($rss,MYSQL_ASSOC);
				$arr_time_in=get_time_in($arrs['time_id']);
				$check_late=check_late($arr_time_in['time_in'],$arrs['check_in']);
			break;
			case 3 : 
				$sss="select * from check_in_out where cid ='$arr[cid]' and shop_id='$arr[shop_id]' and check_date='$arr[check_date]' and check_in_reason='3' order by check_id desc limit 1 ";
				$rss=mysql_query($sss);
				$arrs=mysql_fetch_array($rss,MYSQL_ASSOC);
				$arr_time_in=get_time_in($arrs['time_id']);
				$check_late=check_late("00:##:00",$arrs['check_in']);
			break;
			case 4 : 
				$sss="select * from check_in_out where cid ='$arr[cid]' and shop_id='$arr[shop_id]' and check_date='$arr[check_date]' and check_in_reason='4' order by check_id limit 1 ";
				$rss=mysql_query($sss);
				$arrs=mysql_fetch_array($rss,MYSQL_ASSOC);
				$arr_time_in=get_time_in($arrs['time_id']);
				$check_late=check_late("00:##:00",$arrs['check_in']);
			break;
		}
		$time_name=$arr_time_in['time_name'];
		$text1.="
		<td>
		<table cellpadding='0' cellspacing='1' border='0' bgcolor='#dddddd' >
		<tr>
			<td bgcolor='#ffffff' align='center'><img src='/shop/$arr[check_in_img_path]' width='110' height='83'></td>
		</tr>
		<tr>
			<td bgcolor='#ffffff' align='center'><b>".get_reason($arr['check_in_reason'])."</b></td>
		</tr>
		<tr>
			<td bgcolor='#ffffff' align='center'><b>$check_late[r]</b></td>
		</tr>
		</table>
		</td>
		";
		$i++;
	}
	
	$text="
	<table cellpadding='0' cellspacing='0' border='0' width='100%'>
	<tr>
		<td>
		<table cellpadding='0' cellspacing='0' border='0'>
		<tr>
			<td><img src='img/kdmconfig.png'></td>
			<td>=<b>$cid</b></td>
			<td><img src='img/vline_today.jpg'></td>
			<td><img src='img/clock.png'></td>
			<td>=<b>$time_name</b></td>
		</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td height='2' bgcolor='#ffffff'><img src='img/spacer.gif' height='1'></td>
	</tr>
	<tr>
		<td height='3' bgcolor='#bcbcbc'><img src='img/spacer.gif' height='1'></td>
	</tr>
	<tr>
		<td height='2' bgcolor='#ffffff'><img src='img/spacer.gif' height='1'></td>
	</tr>
	<tr>
		<td background='img/bg_today.jpg' height='140' style='padding-left:10; padding-right:10;'>
		<table cellpadding='0' cellspacing='0' border='0' width='100%'>
		<tr>
			$text1
		</tr>
		</table>
		</td>
	</tr>
	</table>
	";
	return($text);
}

function get_reason($reason_id){
	if($reason_id=='0'){
		return "&nbsp;";
	}else{
		global $local;
		$sql="select * from reason where reason_id = '$reason_id'";
		$rs=mysql_query($sql);
		$arr=mysql_fetch_array($rs);
		return($arr['reason_name']);
	}
}

function finger_scan($cid,$time_id,$reason_id,$check_by="",$unlock_code=""){
	global $local;
	$today=date("Y-m-d");
	$totime=date("H:i:s");
	
	if($check_by=="finger"){
		$unlock_code="";
	}
	
	/**/
	$date_time=date("YmdHis");
	$file_name=$date_time."_".$cid.".jpg";
	$full_path="capture/".$file_name;
	#$command="/usr/bin/lwp-request http://127.0.0.1:8080/0/action/snapshot > /dev/null";
	$command="wget -q http://127.0.0.1:8080/0/action/snapshot > /dev/null";
	@exec( $command );
	usleep(900000);
	$path_capture = "cam1";
	$scopy="/var/www/shop/cam1/snapshot.jpg";
	$tcopy="/var/www/shop/capture/".$file_name;
	@copy($scopy, $tcopy);
	$delete="rm -f /var/www/shop/cam1/*";
	@exec( $delete );
	/**/
	
	$seq=get_seq($cid,$today);
	$shop_ip=SHOP_IP;
	$shop_number=SHOP_NUMBER;
	if( empty($shop_ip) or empty($shop_number) ){
		return false;
	}else{
		$ins="
		insert into 
			check_in_out 
		set 
			cid='$cid',
			time_id='$time_id',
			shop_ip='".SHOP_IP."',
			shop_id='".SHOP_NUMBER."',
			check_date='$today',
			check_in='$totime',
			check_in_img_path='$full_path',
			check_in_seq='$seq',
			check_in_reason='$reason_id',
			check_by='$check_by',
			unlock_code='$unlock_code'
		";
		if(mysql_query($ins)){
			return true;
		}else{
			return false;
		}
	}
}

function capture($cid,$time_id,$reason_id,$cid2=""){
	global $local;
	$today=date("Y-m-d");
	$totime=date("H:i:s");
	$date_time=date("YmdHis");
	$file_name=$date_time."_".$cid.".jpg";
	$full_path="capture/".$file_name;
	#$command="/usr/bin/lwp-request http://127.0.0.1:8080/0/action/snapshot > /dev/null";
	$command="wget -q http://127.0.0.1:8080/0/action/snapshot > /dev/null";
	@exec( $command );
	usleep(900000);
	$path_capture = "cam1";
	$scopy="/var/www/shop/cam1/snapshot.jpg";
	$tcopy="/var/www/shop/capture/".$file_name;
	@copy($scopy, $tcopy);
	$delete="rm -f /var/www/shop/cam1/*";
	@exec( $delete );
	$seq=get_seq($cid,$today);
	$shop_ip=SHOP_IP;
	$shop_number=SHOP_NUMBER;
	if( empty($shop_ip) or empty($shop_number) ){
		echo"
		<script>
			alert('�ͧ���� �ա����');
			window.location='index.php';
		</script>";
	}else{
		$ins="
		insert into 
			check_in_out 
		set 
			cid='$cid',
			cid2='$cid2',
			time_id='$time_id',
			shop_ip='".SHOP_IP."',
			shop_id='".SHOP_NUMBER."',
			check_date='$today',
			check_in='$totime',
			check_in_img_path='$full_path',
			check_in_seq='$seq',
			check_in_reason='$reason_id'
		";
		//echo"$ins";
		mysql_query($ins);
		@chdir("/var/www/shop");
		$tran_command="php -q -f tran.php >>/dev/null 2>>/dev/null &";
		@exec($tran_command);
		echo"<script>window.location='index.php';</script>";
	}
}

function get_first_time_id($cid,$cdate){
	$sql="select * from check_in_out where cid = '$cid' and check_date = '$cdate' order by check_in_seq limit 1";
	$rs=mysql_query($sql);
	$arr=mysql_fetch_array($rs);
	return($arr['time_id']);
}

function get_seq($cid,$cdate){
	$sql="select * from check_in_out where cid = '$cid' and check_date='$cdate'";
	$rs=mysql_query($sql);
	$num=mysql_num_rows($rs);
	if($num == '0')
	{
		$seq=1;
	}else{
		$seq=$num+1;
	}
	return $seq;
}


function get_seq_reason($cid,$cdate){
	$sql="select * from check_reason where cid = '$cid' and check_date='$cdate'";
	$rs=mysql_query($sql);
	$num=mysql_num_rows($rs);
	if($num == '0')
	{
		$seq=1;
	}else{
		$seq=$num+1;
	}
	return $seq;
}

function thaidate($datetime,$shot='0',$abtime='0'){
	$today=explode(" ",$datetime);
	
	$day = substr($today[0],8,2);
	$day_1 = substr($day,0,1);
	$day_2 = substr($day,1,2);
	if($day_1==0) $day = $day_2;
	else $day=$day_1.$day_2;
	switch (substr($today[0],5,2)){
		case "01" : 
			$name_month = "���Ҥ�";
			$sname_month = "�.�.";
		break;
		case "02" : 
			$name_month = "����Ҿѹ��";
			$sname_month = "�.�.";
		break;
		case "03" : 
			$name_month = "�չҤ�";
			$sname_month = "��.�.";
		break;
		case "04" : 
			$name_month = "����¹";
			$sname_month = "��.�.";
		break;
		case "05" : 
			$name_month = "����Ҥ�";
			$sname_month = "�.�.";
		break;
		case "06" : 
			$name_month = "�Զع�¹";
			$sname_month = "��.�.";
		break;
		case "07" : 
			$name_month = "�á�Ҥ�";
			$sname_month = "�.�.";
		break;
		case "08" : 
			$name_month = "�ԧ�Ҥ�";
			$sname_month = "�.�.";
		break;
		case "09" : 
			$name_month = "�ѹ��¹";
			$sname_month = "�.�.";
		break;
		case "10" : 
			$name_month = "���Ҥ�";
			$sname_month = "�.�.";
		break;
		case "11" : 
			$name_month = "��Ȩԡ�¹";
			$sname_month = "�.�.";
		break;
		case "12" : 
			$name_month = "�ѹ�Ҥ�";
			$sname_month = "�.�.";
		break;
	}
	$year=substr($today[0],0,4)+543;
	if($year==543){ $thaidate="-"; }
	if($shot==0){
		$show_month=$name_month;
	}else{
		$show_month=$sname_month;
		$year=substr($year,2,4);
	}
	switch($abtime){
		case 0 : 
			$thaidate="$day $show_month $year-$today[1]";
		break;
		case 1 : 
			$thaidate="$day $show_month $year";
		break;
		case 2 : 
			$thaidate="$today[1]";
		break;
	}
	return($thaidate);
}

function select_hr($name,$val){
	$text="<select name='$name' id='$name'>";
	for($i=0;$i<=23;$i++){
		if(strlen($i)==1){
			$i='0'.$i;
		}
		$text.="<option value='$i' ".selected($i,$val).">$i";
	}
	$text.="</select>";
	return($text);
}

function select_mi($name,$val){
	$text="<select name='$name' id='$name'>";
	for($i=0;$i<=59;$i++){
		if(strlen($i)==1){
			$i='0'.$i;
		}
		$text.="<option value='$i' ".selected($i,$val).">$i";
	}
	$text.="</select>";
	return($text);
}

function selected($v1,$v2){
	if($v1==$v2)
	{
		return(" selected ");
	}else{
		return(" ");
	}
}


?>
