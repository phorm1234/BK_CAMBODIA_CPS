<?php
$local = file("version.txt");
foreach($local as $loc){
    $loc_ver = explode(":",$loc);
    $loc_detail[$loc_ver[0]] = $loc_ver[1];
}
echo "[Local]";
echo "<pre>";
print_r($loc_detail);
echo "</pre>";

$server = file("http://mcs.ssup.co.th/uploads/version/mcs_version.txt");
foreach($server as $ser){
    $ser_ver = explode(":",$ser);
    $ser_detail[$ser_ver[0]] = $ser_ver[1];
}
echo "[Server]";
echo "<pre>";
print_r($ser_detail);
echo "</pre>";
$file_name = str_replace(' ', '', $ser_detail['file_name']);
//$file_name = ereg_replace('[[:space:]]+', '', trim($ser_detail['file_name']));
if(trim($loc_detail['version']) != trim($ser_detail['version'])){
    $file = 'http://mcs.ssup.co.th/uploads/version/'. trim($file_name);
    $newfile = $file_name;

    if (copy($file, $newfile)) {
        $zip = new ZipArchive;
        if ($zip->open($newfile) === TRUE) {
            $zip->extractTo('../');
            $zip->close();
            echo "Updated";
        } else {
            echo 'failed';
        }
    }
}else{
    echo "Not update";
}

/*
$zip = new ZipArchive;
if ($zip->open('test.zip') === TRUE) {
    $zip->extractTo('/my/destination/dir/');
    $zip->close();
    echo 'ok';
} else {
    echo 'failed';
}
/**/