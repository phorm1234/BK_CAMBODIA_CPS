<?php
require 'constant.php';
$type = trim($_GET['type']);
$mid = trim($_GET['mid']);
$data_array = array();
switch ($type){
    case 'vdo':
        $tbl = 'shop_adv';
        $sql = "SELECT path FROM ".$tbl." WHERE adv_id = ".(int)$mid;
        $objQueryjson = mysql_db_query(DBshop,$sql,$objConnectShop) or die(mysql_error());
        $rs = mysql_fetch_array($objQueryjson);
        $file4get = $rs['path'];
        break;
    case 'banner':
        $tbl = 'banner';
        $sql = "SELECT path FROM ".$tbl." WHERE banner_id = ".(int)$mid;
        $objQueryjson = mysql_db_query(DBshop,$sql,$objConnectShop) or die(mysql_error());
        $rs = mysql_fetch_array($objQueryjson);
        $file4get = $rs['path'];
        break;
}
if(count($rs) > 0){
    $filesize = filesize($file4get);
    $md5 = md5_file($file4get);
    $data_array = array('mediaid'=>$mid, 'type'=>$type, 'filesize'=> $filesize, 'MD5'=> $md5, 'msg'=>'Get Data');
}else{
    $data_array = array('mediaid'=>0,'type'=>$type, 'filesize'=> '0', 'MD5'=>'', 'msg'=>'No Data');
}
echo json_encode($data_array, true);
